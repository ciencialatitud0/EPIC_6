# Raw data — GW150914

## Event and release

- Event: **GW150914-v2**
- Event GPS time: `1126259462.4`
- DOI: [10.7935/K5MW2F23](https://doi.org/10.7935/K5MW2F23)
- Release: LOSC/GWOSC 4 kHz, **version 2** (timing-corrected), 32-second HDF5 frames.

Version 1 of the 4096 Hz files is **not** used. GWOSC documents an
approximately one-millisecond timing/phase error in the version-1
downsampled files that was corrected in version 2. That error would be
unacceptable for a project that measures a delay of only a few milliseconds.

## Source files

| Detector | Filename | URL |
|---|---|---|
| H1 (Hanford) | `H-H1_LOSC_4_V2-1126259446-32.hdf5` | `https://gwosc.org/eventapi/html/O1_O2-Preliminary/GW150914/v2/H-H1_LOSC_4_V2-1126259446-32.hdf5` |
| L1 (Livingston) | `L-L1_LOSC_4_V2-1126259446-32.hdf5` | `https://gwosc.org/eventapi/html/O1_O2-Preliminary/GW150914/v2/L-L1_LOSC_4_V2-1126259446-32.hdf5` |

Retrieval date: 2026-08-02, via `acquire_data.py`.

## Checksums and sizes

| Detector | Size (bytes) | Published MD5 | Measured MD5 | Measured SHA-256 |
|---|---|---|---|---|
| H1 | 1,040,592 | `50441a42c13fc1f14e5c4ea5527f1515` | `50441a42c13fc1f14e5c4ea5527f1515` | `6e6976e932074a3b4e4a398ed02c62e30fcaa2781811762caea04937133583f6` |
| L1 | 1,007,420 | `361ae6a040a9fef7897b1e0124d5b0a1` | `361ae6a040a9fef7897b1e0124d5b0a1` | `56706e68c811b15548f1d7ed69d7c48d5fcc62aeb21fbaf131355f3cc5c07189` |

Published MD5 values are from the GWOSC event page for GW150914-v2. Both
measured MD5 values match the published values exactly; `acquire_data.py`
refuses to keep a file whose checksum does not match. The full download
record (URL, size, MD5, SHA-256 per file) is also written machine-readably
to `download_manifest.json`.

## File contents

Each HDF5 file contains, among other groups:

- `strain/Strain` — the 131,072-sample (32 s at 4096 Hz) strain time series,
  with the sample spacing stored in the `Xspacing` attribute
  (`0.000244140625 s`, i.e. 1/4096 s).
- `meta/GPSstart`, `meta/Duration` — both files start at GPS `1126259446`
  and span `32` s.
- `quality/simple/DQmask`, `quality/simple/DQShortnames` — one data-quality
  word per second (32 values), decoded against 7 named bits (`DATA`,
  `CBC_CAT1..3`, `BURST_CAT1..3`).
- `quality/injections/Injmask`, `quality/injections/InjShortnames` — one
  injection-status word per second (32 values), decoded against 5 named
  bits (`NO_CBC_HW_INJ`, `NO_BURST_HW_INJ`, `NO_DETCHAR_HW_INJ`,
  `NO_CW_HW_INJ`, `NO_STOCH_HW_INJ`).

`prepare_data.py` validates these before conditioning. For this release:

- H1: `DQmask == 127` (all 7 quality bits set) and `Injmask == 31` (all 5
  `NO_*` bits set — no hardware injections of any kind) across the full
  32 s record.
- L1: `DQmask == 127`, but `Injmask == 23` (`NO_CBC_HW_INJ`,
  `NO_BURST_HW_INJ` and `NO_DETCHAR_HW_INJ` set; `NO_CW_HW_INJ` is
  **not** set). This means the public L1 record carries a continuous-wave
  hardware injection throughout — a real, documented, unrelated background
  signal, not an instrumental fault. `NO_CBC_HW_INJ` remains set, so no
  compact-binary injection contaminates the event or control interval used
  by this project.

## Licence and acknowledgement

Data are made available by the LIGO Scientific Collaboration and the Virgo
Collaboration under the terms of the [GWOSC Data Use
Policy](https://gwosc.org/detector_data_disclaimer/) (Creative Commons
Attribution 4.0 International licence). Any use of this data in student
material or presentations should include the standard GWOSC/LIGO-Virgo
acknowledgement:

> This research has made use of data, software and/or web tools obtained
> from the Gravitational Wave Open Science Center (gwosc.org), a service of
> the LIGO Laboratory, the LIGO Scientific Collaboration and the Virgo
> Collaboration. LIGO is funded by the U.S. National Science Foundation.
> Virgo is funded by the French Centre National de Recherche Scientifique
> (CNRS), the Italian Istituto Nazionale della Fisica Nucleare (INFN) and
> the Dutch Nikhef, with contributions by Polish and Hungarian institutes.

## Integrity

Do not modify these HDF5 files. Any reprocessing happens downstream in
`prepare_data.py`, which reads them read-only and writes its output to
`student_data/gw150914_prepared.npz`.
